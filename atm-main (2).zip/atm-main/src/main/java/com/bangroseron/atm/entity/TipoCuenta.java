package com.bangroseron.atm.entity;

public enum TipoCuenta {
    AHORROS,
    CORRIENTE,

}
